# PsyLab - Psychophysics Lab

## Authors

- [Christopher A. Brown](https://github.com/cbrown1): <cbrown1@pitt.edu>
- [Kutay B. Sezginel](https://github.com/kbsezginel)
- [Joseph K. Ranweiler](https://github.com/ranweiler)
