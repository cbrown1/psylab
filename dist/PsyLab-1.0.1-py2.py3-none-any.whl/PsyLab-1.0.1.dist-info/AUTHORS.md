# PsyLab - Psychophysics Lab

## Authors

- [Christopher A. Brown](https://github.com/cbrown1): <cbrown1@pitt.edu>
- [Joseph K. Ranweiler](https://github.com/ranweiler)
