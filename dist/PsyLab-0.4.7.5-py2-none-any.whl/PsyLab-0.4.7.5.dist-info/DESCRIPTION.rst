Psylab is a loose collection of modules useful for various aspects of running
psychophysics experiments, although some might be more generally useful.

